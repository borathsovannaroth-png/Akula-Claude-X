package com.akula.claudex

import android.app.ActivityManager
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Environment
import android.os.IBinder
import android.os.StatFs
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.Locale

enum class Status { NO_SHIZUKU, NOT_RUNNING, NEED_PERMISSION, CONNECTING, READY }

enum class AppAction { FORCE_STOP, RESTRICT, ALLOW }

data class AppItem(val pkg: String, val label: String)

private data class Snap(val ramFreeMb: Long, val storageFreeBytes: Long)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("akula", Context.MODE_PRIVATE)

    // ---- Settings (saved) ----
    var showCredit by mutableStateOf(prefs.getLong("hideCreditDay", -1L) != today())
        private set

    // ---- Shizuku / UI state ----
    var status by mutableStateOf(Status.CONNECTING)
        private set
    var busy by mutableStateOf(false)
        private set
    var progress by mutableStateOf("")
        private set
    /** null = nothing run yet (the UI shows a "ready" text). */
    var result by mutableStateOf<String?>(null)
        private set
    var ram by mutableStateOf("--")
        private set
    var storage by mutableStateOf("--")
        private set
    var battery by mutableStateOf("--")
        private set

    // ---- Lite Display (counts down from 15 and goes back unless you press Keep) ----
    var liteCountdown by mutableStateOf(0)
        private set
    private var liteJob: Job? = null

    // ---- Background apps picker ----
    var apps by mutableStateOf<List<AppItem>>(emptyList())
        private set
    var appsLoading by mutableStateOf(false)
        private set
    var selected by mutableStateOf<Set<String>>(emptySet())
        private set

    private var service: IShellService? = null
    private var binding = false
    @Volatile private var cancelled = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            service = if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
            status = if (service != null) Status.READY else Status.CONNECTING
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            binding = false
            refresh()
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        binding = false
        refresh()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    init {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refreshStats()
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
        super.onCleared()
    }

    // ---------------- Settings ----------------

    private fun today(): Long = System.currentTimeMillis() / 86_400_000L

    fun openCredit() { showCredit = true }
    fun closeCredit() { showCredit = false }
    fun hideCreditToday() {
        prefs.edit().putLong("hideCreditDay", today()).apply()
        showCredit = false
    }

    // ---------------- Shizuku connection ----------------

    private fun shizukuInstalled(): Boolean = try {
        getApplication<Application>().packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
        true
    } catch (_: Exception) {
        false
    }

    /** Re-checks Shizuku state and connects the shell service when everything is ready. */
    fun refresh() {
        refreshStats()
        if (!Shizuku.pingBinder()) {
            service = null
            binding = false
            status = if (shizukuInstalled()) Status.NOT_RUNNING else Status.NO_SHIZUKU
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            status = Status.NEED_PERMISSION
            return
        }
        if (service != null) {
            status = Status.READY
            return
        }
        if (binding) return
        status = Status.CONNECTING
        binding = true
        val ctx = getApplication<Application>()
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .processNameSuffix("shell")
            .daemon(false)
            .version(2)
        try {
            Shizuku.bindUserService(args, connection)
        } catch (e: Exception) {
            binding = false
            status = Status.NOT_RUNNING
            result = "Could not connect: ${e.message}"
        }
    }

    /** "Check again" button: forgets a stuck connection attempt and starts over. */
    fun retry() {
        binding = false
        refresh()
    }

    fun requestPermission() {
        if (Shizuku.pingBinder()) Shizuku.requestPermission(100)
    }

    // ---------------- Live stats ----------------

    private fun ramInfo(): Pair<Long, Long> {
        val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return (mi.availMem / 1_048_576) to (mi.totalMem / 1_048_576)
    }

    private fun storageInfo(): Pair<Long, Long> {
        val sf = StatFs(Environment.getDataDirectory().path)
        return sf.availableBytes to sf.totalBytes
    }

    private fun snap() = Snap(ramInfo().first, storageInfo().first)

    private fun gb(bytes: Long) = String.format(Locale.US, "%.2f", bytes / 1_073_741_824.0)

    fun refreshStats() {
        val (rf, rt) = ramInfo()
        ram = "$rf / $rt MB"

        val (sfree, stotal) = storageInfo()
        storage = "${gb(sfree)} / ${gb(stotal)} GB"

        val bi = getApplication<Application>().registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        battery = if (level >= 0 && scale > 0) {
            "${level * 100 / scale}% · ${String.format(Locale.US, "%.1f", temp)}°C" + if (charging) " ⚡" else ""
        } else "--"
    }

    // ---------------- Tweaks (each one runs real shell commands through Shizuku) ----------------

    private val animKeys = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private fun animCommands(scale: String) = animKeys.map { "settings put global $it $scale" }
    private val animVerify = animKeys.map { it.removeSuffix("_scale") to "settings get global $it" }

    fun animationsScale(scale: String, label: String) = runTweak(label, animCommands(scale), animVerify)

    /** One tap: faster animations + free RAM + clear caches, then shows before/after numbers. */
    fun boost() = runTweak(
        "One-tap Boost",
        animCommands("0.5") + listOf("am kill-all", "pm trim-caches 999999999999"),
        animVerify,
        timeoutMs = 90_000L,
        diff = true
    )

    fun freeRam() = runTweak("Free RAM", listOf("am kill-all"), diff = true)

    fun clearCaches() = runTweak(
        "Clear app caches",
        listOf("pm trim-caches 999999999999"),
        timeoutMs = 90_000L,
        diff = true
    )

    fun optimizeApps() = runTweak(
        "Optimize apps",
        listOf("cmd package compile -m speed-profile -a"),
        timeoutMs = 20 * 60_000L,
        diff = true
    )

    fun setRefreshRate(hz: Int) = runTweak(
        "Refresh rate $hz Hz",
        listOf("settings put system peak_refresh_rate $hz", "settings put system min_refresh_rate $hz"),
        listOf("peak" to "settings get system peak_refresh_rate", "min" to "settings get system min_refresh_rate")
    )

    fun resetRefreshRate() = runTweak(
        "Reset refresh rate",
        listOf("settings delete system peak_refresh_rate", "settings delete system min_refresh_rate"),
        listOf("peak" to "settings get system peak_refresh_rate", "min" to "settings get system min_refresh_rate")
    )

    fun setBatterySaver(on: Boolean) = runTweak(
        if (on) "Battery saver ON" else "Battery saver OFF",
        listOf("settings put global low_power ${if (on) 1 else 0}"),
        listOf("low_power" to "settings get global low_power")
    )

    // ---------------- Lite Display (lower resolution = less work for a weak GPU) ----------------

    fun applyLite(percent: Int) {
        if (percent !in 50..100) return
        val s = service ?: run {
            result = "Shizuku is not ready yet."
            return
        }
        if (busy || liteCountdown > 0) return
        busy = true
        progress = "Lite Display $percent%"
        viewModelScope.launch(Dispatchers.IO) {
            var msg: String
            var started = false
            try {
                val size = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(s.exec("wm size", 10_000L))
                val dens = Regex("Physical density:\\s*(\\d+)").find(s.exec("wm density", 10_000L))
                if (size == null || dens == null) {
                    msg = "⚠ Lite Display – could not read your screen size, nothing was changed."
                } else {
                    val w = size.groupValues[1].toInt()
                    val h = size.groupValues[2].toInt()
                    val d = dens.groupValues[1].toInt()
                    val nw = (w * percent / 100) / 2 * 2
                    val nh = (h * percent / 100) / 2 * 2
                    val nd = d * percent / 100
                    s.exec("wm size ${nw}x$nh", 10_000L)
                    s.exec("wm density $nd", 10_000L)
                    val check = s.exec("wm size", 10_000L).trim()
                    msg = "✓ Lite Display $percent%\n" +
                        "Screen: ${w}x$h → ${nw}x$nh · density $d → $nd\n$check\n" +
                        "Press Keep within 15 seconds, or it goes back by itself."
                    started = true
                }
            } catch (e: Exception) {
                msg = "⚠ Lite Display – failed: ${e.message}"
            }
            withContext(Dispatchers.Main) {
                result = msg
                busy = false
                progress = ""
                if (started) startLiteCountdown()
            }
        }
    }

    private fun startLiteCountdown() {
        liteJob?.cancel()
        liteCountdown = 15
        liteJob = viewModelScope.launch {
            for (i in 14 downTo 0) {
                delay(1000)
                liteCountdown = i
            }
            revertLite(auto = true)
        }
    }

    fun keepLite() {
        liteJob?.cancel()
        liteCountdown = 0
        result = "✓ Lite Display kept. Use Reset (or Reset all tweaks) to go back to normal."
    }

    fun revertLite(auto: Boolean = false) {
        liteJob?.cancel()
        liteCountdown = 0
        val s = service
        viewModelScope.launch(Dispatchers.IO) {
            try {
                s?.exec("wm size reset", 10_000L)
                s?.exec("wm density reset", 10_000L)
            } catch (_: Exception) {
            }
            withContext(Dispatchers.Main) {
                result = if (auto) "↩ Display went back to normal (you did not press Keep)." else "↩ Display went back to normal."
                refreshStats()
            }
        }
    }

    // ---------------- Launch-speed proof (real start time printed by Android) ----------------

    /**
     * Force-stops the app, opens it 3 times from cold and reads "TotalTime" from `am start -W`.
     * The middle value is saved, so after Optimize you can test again and see the real change.
     */
    fun launchTest(pkg: String, label: String) {
        val s = service ?: run {
            result = "Shizuku is not ready yet."
            return
        }
        if (busy || liteCountdown > 0) return
        val ctx = getApplication<Application>()
        val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToString()
        if (comp == null || !comp.matches(Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)*/[A-Za-z0-9_.$]+$"))) {
            result = "⚠ $label has no normal launch screen, so it can't be timed."
            return
        }
        val back = ctx.packageName + "/" + MainActivity::class.java.name
        busy = true
        cancelled = false
        progress = "Launch test: $label (the app will open 3 times)"
        viewModelScope.launch(Dispatchers.IO) {
            val times = mutableListOf<Int>()
            var problem: String? = null
            try {
                repeat(3) {
                    if (cancelled) return@repeat
                    s.exec("am force-stop $pkg", 15_000L)
                    delay(700)
                    val o = s.exec("am start -W -n $comp", 30_000L)
                    val t = Regex("TotalTime:\\s*(\\d+)").find(o)?.groupValues?.get(1)?.toIntOrNull()
                    if (t == null) problem = o.trim().takeLast(160) else times += t
                    delay(1500)
                }
                s.exec("am force-stop $pkg", 15_000L)
                s.exec("am start -W -n $back", 15_000L) // bring AkulaClaudeX back to the front
            } catch (e: Exception) {
                problem = e.message
            }
            val text = when {
                cancelled -> "■ Launch test – cancelled"
                times.isEmpty() -> "⚠ Launch test – no time was reported. ${problem ?: ""}".trim()
                else -> {
                    val median = times.sorted()[times.size / 2]
                    val key = "launch_$pkg"
                    val last = prefs.getInt(key, -1)
                    prefs.edit().putInt(key, median).apply()
                    val cmp = if (last < 0) {
                        "First test saved. Run Optimize, then test this app again to see the difference."
                    } else {
                        val d = last - median
                        val pct = if (last > 0) kotlin.math.abs(d) * 100 / last else 0
                        when {
                            d > 0 -> "Last test: $last ms → now $median ms (${d} ms faster, $pct%)"
                            d < 0 -> "Last test: $last ms → now $median ms (${-d} ms slower, $pct%)"
                            else -> "Last test: $last ms → now $median ms (same)"
                        }
                    }
                    "✓ Launch test – $label\n" +
                        "Cold start runs: ${times.joinToString(", ")} ms\n" +
                        "Cold start (middle value): $median ms\n$cmp\n" +
                        "Small changes (about 10%) can be normal noise. Trust big changes."
                }
            }
            withContext(Dispatchers.Main) {
                result = text
                busy = false
                progress = ""
                refreshStats()
            }
        }
    }

    fun resetAll() = runTweak(
        "Reset all tweaks",
        animCommands("1") + listOf(
            "settings delete system peak_refresh_rate",
            "settings delete system min_refresh_rate",
            "settings put global low_power 0",
            "wm size reset",
            "wm density reset"
        ),
        animVerify
    )

    // ---------------- Background apps picker ----------------

    private val pkgRegex = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)*$")

    fun loadApps() {
        val s = service ?: run {
            result = "Shizuku is not ready yet."
            return
        }
        if (appsLoading) return
        appsLoading = true
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val list = try {
                val out = s.exec("pm list packages -3", 30_000L)
                val pm = ctx.packageManager
                out.lineSequence()
                    .map { it.trim() }
                    .filter { it.startsWith("package:") }
                    .map { it.removePrefix("package:") }
                    .filter { it.matches(pkgRegex) && it != ctx.packageName }
                    .map { p ->
                        val label = try {
                            pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
                        } catch (_: Exception) {
                            p
                        }
                        AppItem(p, label)
                    }
                    .sortedBy { it.label.lowercase() }
                    .toList()
            } catch (_: Exception) {
                emptyList()
            }
            withContext(Dispatchers.Main) {
                apps = list
                selected = selected.filter { p -> list.any { it.pkg == p } }.toSet()
                appsLoading = false
            }
        }
    }

    fun toggleApp(pkg: String) {
        selected = if (pkg in selected) selected - pkg else selected + pkg
    }

    fun selectAllApps() { selected = apps.map { it.pkg }.toSet() }
    fun clearSelection() { selected = emptySet() }

    fun appsAction(kind: AppAction) {
        val pkgs = selected.filter { it.matches(pkgRegex) }
        if (pkgs.isEmpty()) return
        val cmds = pkgs.flatMap { p ->
            when (kind) {
                AppAction.FORCE_STOP -> listOf("am force-stop $p")
                AppAction.RESTRICT -> listOf(
                    "cmd appops set $p RUN_IN_BACKGROUND deny",
                    "cmd appops set $p RUN_ANY_IN_BACKGROUND deny"
                )
                AppAction.ALLOW -> listOf(
                    "cmd appops set $p RUN_IN_BACKGROUND allow",
                    "cmd appops set $p RUN_ANY_IN_BACKGROUND allow"
                )
            }
        }
        val title = when (kind) {
            AppAction.FORCE_STOP -> "Force stop ${pkgs.size} app(s)"
            AppAction.RESTRICT -> "Restrict ${pkgs.size} app(s)"
            AppAction.ALLOW -> "Allow ${pkgs.size} app(s)"
        }
        runTweak(title, cmds, diff = kind == AppAction.FORCE_STOP)
    }

    // ---------------- Runner ----------------

    fun cancel() {
        if (!busy) return
        cancelled = true
        viewModelScope.launch(Dispatchers.IO) {
            try { service?.cancel() } catch (_: Exception) { }
        }
    }

    private fun looksBad(o: String): Boolean {
        val l = o.lowercase()
        return "exception" in l || "error:" in l || "blocked:" in l ||
            "unknown command" in l || "permission denied" in l || l.startsWith("error")
    }

    private fun diffLines(b: Snap, a: Snap): List<String> {
        val dr = a.ramFreeMb - b.ramFreeMb
        val ds = (a.storageFreeBytes - b.storageFreeBytes) / 1_048_576
        return listOf(
            "RAM free: ${b.ramFreeMb} → ${a.ramFreeMb} MB (${if (dr >= 0) "+" else ""}$dr)",
            "Storage free: ${gb(b.storageFreeBytes)} → ${gb(a.storageFreeBytes)} GB (${if (ds >= 0) "+" else ""}$ds MB)"
        )
    }

    private fun runTweak(
        title: String,
        commands: List<String>,
        verify: List<Pair<String, String>> = emptyList(),
        timeoutMs: Long = 60_000L,
        diff: Boolean = false
    ) {
        val s = service ?: run {
            result = "Shizuku is not ready yet."
            return
        }
        if (busy) return
        busy = true
        cancelled = false
        progress = title
        viewModelScope.launch(Dispatchers.IO) {
            val lines = mutableListOf<String>()
            var problem = false
            val before = snap()
            try {
                for (c in commands) {
                    if (cancelled) break
                    val o = s.exec(c, timeoutMs).trim()
                    if (o.isNotEmpty()) {
                        lines += o.takeLast(300)
                        if (looksBad(o)) problem = true
                    }
                }
                if (!cancelled) {
                    for ((label, c) in verify) {
                        lines += "$label = ${s.exec(c, 10_000L).trim().ifBlank { "?" }}"
                    }
                }
            } catch (e: Exception) {
                lines += "failed: ${e.message}"
                problem = true
            }
            if (!cancelled) delay(900) // let Android settle before measuring "after"
            val after = snap()
            if (diff && !cancelled) lines += diffLines(before, after)

            val head = when {
                cancelled -> "■ $title – cancelled"
                problem -> "⚠ $title – finished with warnings"
                else -> "✓ $title – done"
            }
            val text = (listOf(head) + lines).joinToString("\n").take(1200)
            withContext(Dispatchers.Main) {
                result = text
                busy = false
                progress = ""
                refreshStats()
            }
        }
    }
}
