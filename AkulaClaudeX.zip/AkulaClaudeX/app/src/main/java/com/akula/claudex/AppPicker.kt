package com.akula.claudex

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Full-screen list of the user's installed apps: force stop, restrict background, or allow background again. */
@Composable
fun AppPicker(vm: MainViewModel, onClose: () -> Unit) {
    val p = LocalPal.current
    BackHandler { onClose() }
    val canAct = vm.status == Status.READY && !vm.busy && vm.selected.isNotEmpty()

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(p.bg))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text("Background apps", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Apps you installed · Selected: ${vm.selected.size}",
                    color = p.accent, fontSize = 12.sp
                )
            }
            GlassButton("Close", onClick = onClose)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Select all", Modifier.weight(1f), onClick = vm::selectAllApps)
            GlassChip("Clear", Modifier.weight(1f), onClick = vm::clearSelection)
        }

        Box(Modifier.weight(1f).fillMaxWidth().glass(RoundedCornerShape(20.dp))) {
            when {
                vm.appsLoading -> Text(
                    "Loading apps…",
                    color = p.soft, fontSize = 14.sp, modifier = Modifier.align(Alignment.Center)
                )
                vm.apps.isEmpty() -> Text(
                    "No user apps found",
                    color = p.soft, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(16.dp)
                )
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.apps, key = { it.pkg }) { app ->
                        val checked = app.pkg in vm.selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.toggleApp(app.pkg) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val shape = RoundedCornerShape(6.dp)
                            Box(
                                Modifier
                                    .size(22.dp)
                                    .clip(shape)
                                    .then(
                                        if (checked) Modifier.background(Brush.horizontalGradient(listOf(p.violet, p.cyan)), shape)
                                        else Modifier.border(1.5.dp, p.soft, shape)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (checked) Text("✓", color = p.btnText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(app.label, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(app.pkg, color = p.soft, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        if (vm.busy) {
            BusyBar(vm.progress, onCancel = vm::cancel)
        } else {
            vm.result?.lines()?.firstOrNull()?.let { Text(it, color = p.soft, fontSize = 12.sp) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("Force stop", Modifier.weight(1f), canAct) { vm.appsAction(AppAction.FORCE_STOP) }
            GlassButton("Restrict", Modifier.weight(1f), canAct) { vm.appsAction(AppAction.RESTRICT) }
            GlassButton("Allow", Modifier.weight(1f), canAct) { vm.appsAction(AppAction.ALLOW) }
        }
        val one = vm.apps.firstOrNull { it.pkg in vm.selected }
        GlassButton(
            "Test launch speed (select 1 app)",
            Modifier.fillMaxWidth(),
            vm.status == Status.READY && !vm.busy && vm.selected.size == 1 && one != null
        ) { one?.let { vm.launchTest(it.pkg, it.label) } }
        Text(
            "Force stop = close now. Restrict = block background running until you tap Allow. Restricted apps may delay notifications.",
            color = p.soft, fontSize = 11.sp
        )
    }
}
