package com.akula.claudex

import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku-started process (shell privileges, no root).
 *
 * Safety: this service does NOT run arbitrary shell text. Every command is split into arguments,
 * checked against a strict allow-list and started WITHOUT a shell, so nothing can be chained or injected.
 */
class ShellService : IShellService.Stub() {

    @Volatile private var current: Process? = null
    @Volatile private var cancelled = false

    override fun destroy() {
        exitProcess(0)
    }

    override fun cancel() {
        cancelled = true
        current?.destroy()
    }

    override fun exec(command: String, timeoutMs: Long): String {
        val args = command.trim().split(Regex("\\s+"))
        if (!allowed(args)) return "blocked: command not allowed"
        cancelled = false
        return try {
            val p = ProcessBuilder(args).redirectErrorStream(true).start()
            current = p
            val sb = StringBuffer()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(2048)
                        while (true) {
                            val n = r.read(buf)
                            if (n < 0) break
                            if (sb.length < MAX_OUT) sb.append(buf, 0, n)
                        }
                    }
                } catch (_: Exception) {
                }
            }
            reader.start()

            val end = System.currentTimeMillis() + timeoutMs
            var timedOut = false
            while (!finished(p)) {
                if (System.currentTimeMillis() > end) {
                    timedOut = true
                    p.destroy()
                    break
                }
                Thread.sleep(100)
            }
            reader.join(1000)
            current = null

            val out = sb.toString().trim()
            when {
                cancelled -> "$out\n[cancelled]".trim()
                timedOut -> "$out\n[timed out]".trim()
                else -> out
            }
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    private fun finished(p: Process): Boolean = try {
        p.exitValue()
        true
    } catch (_: IllegalThreadStateException) {
        false
    }

    private fun allowed(a: List<String>): Boolean = when (a.getOrNull(0)) {
        "settings" -> when (a.getOrNull(1)) {
            "get", "delete" -> a.size == 4 && a[2] in NAMESPACES && a[3] in SETTING_KEYS
            "put" -> a.size == 5 && a[2] in NAMESPACES && a[3] in SETTING_KEYS && NUMBER.matches(a[4])
            else -> false
        }
        "am" -> (a.size == 2 && a[1] == "kill-all") ||
            (a.size == 3 && a[1] == "force-stop" && PKG.matches(a[2])) ||
            // Launch-speed test: "am start -W -n package/Activity" prints the real start time.
            (a.size == 5 && a[1] == "start" && a[2] == "-W" && a[3] == "-n" && COMPONENT.matches(a[4]))
        "pm" -> (a.size == 3 && a[1] == "trim-caches" && a[2].isNotEmpty() && a[2].all { it.isDigit() }) ||
            a == listOf("pm", "list", "packages", "-3")
        "cmd" -> a == listOf("cmd", "package", "compile", "-m", "speed-profile", "-a") ||
            (a.size == 6 && a[1] == "appops" && a[2] == "set" && PKG.matches(a[3]) &&
                a[4] in APPOPS && a[5] in setOf("allow", "deny"))
        "wm" -> wmAllowed(a)
        else -> false
    }

    /** Lite Display: only "wm size", "wm density", sane WxH / density values, or "reset". */
    private fun wmAllowed(a: List<String>): Boolean {
        if (a.size == 2) return a[1] == "size" || a[1] == "density"
        if (a.size != 3) return false
        val v = a[2]
        return when (a[1]) {
            "size" -> v == "reset" || (SIZE.matches(v) && sizeOk(v))
            "density" -> v == "reset" || (v.all { it.isDigit() } && v.length in 3..4 && v.toInt() in 120..800)
            else -> false
        }
    }

    private fun sizeOk(v: String): Boolean {
        val (w, h) = v.split("x").map { it.toIntOrNull() ?: return false }
        return w in 320..4000 && h in 320..4000
    }

    private companion object {
        const val MAX_OUT = 20_000
        val NAMESPACES = setOf("global", "system")
        val SETTING_KEYS = setOf(
            "window_animation_scale", "transition_animation_scale", "animator_duration_scale",
            "peak_refresh_rate", "min_refresh_rate", "low_power"
        )
        val APPOPS = setOf("RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND")
        val NUMBER = Regex("^[0-9]+(\\.[0-9]+)?$")
        val PKG = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)*$")
        val COMPONENT = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)*/[A-Za-z0-9_.$]+$")
        val SIZE = Regex("^[0-9]{3,4}x[0-9]{3,4}$")
    }
}
