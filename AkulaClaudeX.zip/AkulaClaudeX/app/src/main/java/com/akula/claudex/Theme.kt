package com.akula.claudex

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** One fixed dark liquid-glass look (no theme switch, no language switch). */
@Immutable
data class Pal(
    val bg: List<Color>,
    val text: Color,
    val soft: Color,
    val accent: Color,
    val violet: Color,
    val cyan: Color,
    val glassTop: Color,
    val glassBottom: Color,
    val edgeA: Color,
    val edgeB: Color,
    val edgeC: Color,
    val btnText: Color,
    val scrim: Color,
    val good: Color,
    val warn: Color,
    val orbV: Float,
    val orbC: Float
)

val DarkPal = Pal(
    bg = listOf(Color(0xFF070A14), Color(0xFF101733), Color(0xFF0A0F1F)),
    text = Color(0xFFF2F5FF),
    soft = Color(0xFFB7C0DD),
    accent = Color(0xFF00E5FF),
    violet = Color(0xFF6C5CFF),
    cyan = Color(0xFF00E5FF),
    glassTop = Color.White.copy(alpha = 0.20f),
    glassBottom = Color.White.copy(alpha = 0.06f),
    edgeA = Color.White.copy(alpha = 0.60f),
    edgeB = Color.White.copy(alpha = 0.06f),
    edgeC = Color.White.copy(alpha = 0.30f),
    btnText = Color(0xFF05070F),
    scrim = Color(0xAA000000),
    good = Color(0xFF3DFFA2),
    warn = Color(0xFFFFC857),
    orbV = 0.35f,
    orbC = 0.28f
)

val LocalPal = staticCompositionLocalOf { DarkPal }
