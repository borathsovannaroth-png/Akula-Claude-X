package com.akula.claudex

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Cheap "liquid glass": translucent gradient fill + bright edge. No blur, so it stays smooth on low-end GPUs. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(22.dp)): Modifier {
    val p = LocalPal.current
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(p.glassTop, p.glassBottom)))
        .border(1.dp, Brush.linearGradient(listOf(p.edgeA, p.edgeB, p.edgeC)), shape)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(14.dp)
    val a = if (enabled) 1f else 0.35f
    Box(
        modifier
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(p.violet.copy(alpha = a), p.cyan.copy(alpha = a))), shape)
            .then(
                if (enabled) Modifier.clickable {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                } else Modifier
            )
            .padding(horizontal = 14.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (enabled) p.btnText else p.btnText.copy(alpha = 0.5f),
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
    }
}

/** Small outlined pill (select all, cancel...). */
@Composable
fun GlassChip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .glass(RoundedCornerShape(50))
            .clickable {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(text: String) {
    val p = LocalPal.current
    Text(text, color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
fun TweakCard(title: String, desc: String, button: String, enabled: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().glass().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(desc, color = p.soft, fontSize = 12.sp)
        }
        GlassButton(button, enabled = enabled, onClick = onClick)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier) {
    val p = LocalPal.current
    Column(modifier.glass().padding(12.dp)) {
        Text(label, color = p.soft, fontSize = 11.sp)
        Text(value, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Progress bar + Cancel, shown while a tweak is running. */
@Composable
fun BusyBar(label: String, onCancel: () -> Unit) {
    val p = LocalPal.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Working… $label",
                color = p.text, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(end = 8.dp)
            )
            GlassChip("Cancel", onClick = onCancel)
        }
        LinearProgressIndicator(
            modifier = Modifier.fillMaxWidth(),
            color = p.accent,
            trackColor = p.soft.copy(alpha = 0.25f)
        )
    }
}

@Composable
fun ConfirmOverlay(
    title: String,
    body: String,
    onYes: () -> Unit,
    onNo: () -> Unit,
    yesText: String = "Continue",
    noText: String = "Cancel"
) {
    val p = LocalPal.current
    BackHandler { onNo() }
    Box(
        Modifier
            .fillMaxSize()
            .background(p.scrim)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp).glass(RoundedCornerShape(26.dp)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(body, color = p.soft, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassChip(noText, Modifier.weight(1f), onClick = onNo)
                GlassButton(yesText, Modifier.weight(1f), onClick = onYes)
            }
        }
    }
}

/** The credit "watermark board": liquid-glass card that pops up on launch, with a wide slim X bar to close it. */
@Composable
fun CreditOverlay(visible: Boolean, onClose: () -> Unit, onHideToday: () -> Unit) {
    val p = LocalPal.current
    val uri = LocalUriHandler.current
    BackHandler(enabled = visible) { onClose() }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(220)) + slideInVertically(tween(320)) { it / 3 },
        exit = fadeOut(tween(180)) + slideOutVertically(tween(240)) { it / 3 }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(p.scrim)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Please add credit to us bro, let's gooo! 🔥",
                        color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Hi Maaa Boyy 👋",
                        color = p.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "We are Akula Team, from Borath Sovannroth and Claude, also known as ma big broo.",
                        color = p.text, fontSize = 14.sp
                    )
                    Text(
                        "Please keep the rights with us. No stealing or copying allowed.",
                        color = p.soft, fontSize = 13.sp
                    )
                    Text(
                        "Media",
                        color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                    )
                    LinkChip("Telegram · t.me/Rachana_lover21") { uri.openUri("https://t.me/Rachana_lover21") }
                    LinkChip("TikTok · @only_florian_naz") { uri.openUri("https://www.tiktok.com/@only_florian_naz") }
                    GlassChip(
                        "Don't show again today",
                        Modifier.fillMaxWidth(),
                        onClick = onHideToday
                    )
                }

                // Wide + slim X bar to dismiss
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .glass(RoundedCornerShape(19.dp))
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✕", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun LinkChip(text: String, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(p.text.copy(alpha = 0.08f))
            .border(BorderStroke(1.dp, p.text.copy(alpha = 0.22f)), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(text, color = p.text, fontSize = 13.sp)
    }
}
