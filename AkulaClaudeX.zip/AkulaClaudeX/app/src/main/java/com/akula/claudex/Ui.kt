package com.akula.claudex

import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay

enum class Pending { OPTIMIZE, RESET }

@Composable
fun AkulaApp(vm: MainViewModel) {
    run {
        val p = DarkPal

        var showApps by rememberSaveable { mutableStateOf(false) }
        var pending by rememberSaveable { mutableStateOf<Pending?>(null) }

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(p.bg))) {
            Box(
                Modifier
                    .size(280.dp)
                    .offset((-90).dp, (-70).dp)
                    .background(Brush.radialGradient(listOf(p.violet.copy(alpha = p.orbV), Color.Transparent)), CircleShape)
            )
            Box(
                Modifier
                    .size(320.dp)
                    .align(Alignment.BottomEnd)
                    .offset(100.dp, 90.dp)
                    .background(Brush.radialGradient(listOf(p.cyan.copy(alpha = p.orbC), Color.Transparent)), CircleShape)
            )

            Home(
                vm,
                onOpenApps = { showApps = true; vm.loadApps() },
                onConfirm = { pending = it }
            )

            if (showApps) AppPicker(vm, onClose = { showApps = false })

            pending?.let { pd ->
                val title: String
                val body: String
                when (pd) {
                    Pending.OPTIMIZE -> {
                        title = "Optimize apps?"
                        body = "This can take several minutes and uses battery. Keep your phone on the charger."
                    }
                    Pending.RESET -> {
                        title = "Reset all tweaks?"
                        body = "Animations, refresh rate, display size and battery saver go back to default."
                    }
                }
                ConfirmOverlay(
                    title, body,
                    onYes = {
                        when (pd) {
                            Pending.OPTIMIZE -> vm.optimizeApps()
                            Pending.RESET -> vm.resetAll()
                        }
                        pending = null
                    },
                    onNo = { pending = null }
                )
            }

            if (vm.liteCountdown > 0) {
                ConfirmOverlay(
                    "Keep this display?",
                    "If you can read this, press Keep. If you do nothing, the screen goes back to normal in ${vm.liteCountdown} seconds.",
                    onYes = vm::keepLite,
                    onNo = { vm.revertLite() },
                    yesText = "Keep",
                    noText = "Go back now"
                )
            }

            CreditOverlay(visible = vm.showCredit, onClose = vm::closeCredit, onHideToday = vm::hideCreditToday)
        }
    }
}

@Composable
private fun Home(vm: MainViewModel, onOpenApps: () -> Unit, onConfirm: (Pending) -> Unit) {
    val p = LocalPal.current

    // Live stats refresh every 3 s, but only while the app is on screen (saves battery).
    val owner = LocalContext.current as ComponentActivity
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refreshStats()
                delay(3000)
            }
        }
    }

    val ready = vm.status == Status.READY && !vm.busy

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text("AkulaClaudeX", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Android Performance & System Tweaking Utility",
                    color = p.accent, fontSize = 12.sp
                )
            }
            GlassButton("Credits", onClick = vm::openCredit)
        }
        Text(
            "Performance tweaks powered by Shizuku, no root needed.",
            color = p.soft, fontSize = 13.sp
        )

        StatusCard(vm)

        // One-tap boost
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("One-tap Boost", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Faster animations + free RAM + clear caches in one go, then shows before/after numbers.",
                color = p.soft, fontSize = 12.sp
            )
            GlassButton("Boost", Modifier.fillMaxWidth(), enabled = ready, onClick = vm::boost)
        }

        // Result (right under Boost so you always see what happened)
        SectionTitle("Result")
        Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
            if (vm.busy) {
                BusyBar(vm.progress, onCancel = vm::cancel)
            } else {
                Text(
                    vm.result ?: "Ready. Pick a tweak below.",
                    color = p.text, fontSize = 13.sp
                )
            }
        }

        // Live device stats (read from the system, not made up)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("RAM free", vm.ram, Modifier.weight(1f))
            StatTile("Storage free", vm.storage, Modifier.weight(1f))
        }
        StatTile("Battery", vm.battery, Modifier.fillMaxWidth())

        SectionTitle("Smooth UI")
        TweakCard(
            "Faster animations (0.5x)",
            "Halves window, transition and animator scales so the UI feels quicker.",
            "Apply", ready
        ) { vm.animationsScale("0.5", "Faster animations") }
        TweakCard(
            "Animations off",
            "Fastest possible feel on weak phones. Screens switch instantly.",
            "Apply", ready
        ) { vm.animationsScale("0", "Animations off") }
        TweakCard(
            "Restore animations (1x)",
            "Back to the Android default.",
            "Restore", ready
        ) { vm.animationsScale("1", "Restore animations") }

        SectionTitle("Memory & storage")
        TweakCard(
            "Free RAM",
            "Stops cached background processes so more memory is available right now.",
            "Clean", ready, vm::freeRam
        )
        TweakCard(
            "Clear app caches",
            "Asks Android to trim cached files across all apps.",
            "Clear", ready, vm::clearCaches
        )

        SectionTitle("App speed")
        TweakCard(
            "Optimize apps",
            "Recompiles installed apps with the speed-profile ART filter. Can take a few minutes. Best while charging.",
            "Optimize", ready
        ) { onConfirm(Pending.OPTIMIZE) }

        TweakCard(
            "Launch-speed proof",
            "Measures how fast an app really opens (cold start, in milliseconds). Test an app, run Optimize, test it again and compare. Open Background apps, select ONE app, then tap Test launch.",
            "Pick app", ready, onOpenApps
        )

        SectionTitle("Manage apps")
        TweakCard(
            "Background apps",
            "Pick apps to force stop, or block them from running in the background.",
            "Open", ready, onOpenApps
        )

        SectionTitle("Display")
        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Refresh rate", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                "Lock the screen refresh rate. Works only if your display supports it. 60 Hz saves battery.",
                color = p.soft, fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("60 Hz", Modifier.weight(1f), ready) { vm.setRefreshRate(60) }
                GlassButton("90 Hz", Modifier.weight(1f), ready) { vm.setRefreshRate(90) }
                GlassButton("120 Hz", Modifier.weight(1f), ready) { vm.setRefreshRate(120) }
                GlassButton("Reset", Modifier.weight(1f), ready, vm::resetRefreshRate)
            }
        }

        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Lite Display", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                "Lowers the screen resolution so a weak GPU has less to draw. Games and scrolling feel smoother. " +
                    "After you tap, press Keep within 15 seconds or the screen goes back by itself.",
                color = p.soft, fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("90%", Modifier.weight(1f), ready) { vm.applyLite(90) }
                GlassButton("80%", Modifier.weight(1f), ready) { vm.applyLite(80) }
                GlassButton("70%", Modifier.weight(1f), ready) { vm.applyLite(70) }
                GlassButton("Reset", Modifier.weight(1f), ready) { vm.revertLite() }
            }
        }

        SectionTitle("Battery")
        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Battery saver", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(
                "Turns Android's battery saver on or off.",
                color = p.soft, fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("On", Modifier.weight(1f), ready) { vm.setBatterySaver(true) }
                GlassButton("Off", Modifier.weight(1f), ready) { vm.setBatterySaver(false) }
            }
        }

        SectionTitle("Safety")
        TweakCard(
            "Reset all tweaks",
            "Restores animations, refresh rate, display size and battery saver to default.",
            "Reset", ready
        ) { onConfirm(Pending.RESET) }

        Text(
            "Made by Akula Team · keep the credit",
            color = p.soft.copy(alpha = 0.7f),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
    }
}

@Composable
private fun StatusCard(vm: MainViewModel) {
    val p = LocalPal.current
    val info: Triple<String, String, String?> = when (vm.status) {
        Status.READY -> Triple(
            "Shizuku connected",
            "All tweaks are unlocked.",
            null
        )
        Status.CONNECTING -> Triple(
            "Connecting…",
            "Talking to Shizuku. Stuck? Tap Retry.",
            "Retry"
        )
        Status.NEED_PERMISSION -> Triple(
            "Permission needed",
            "Allow AkulaClaudeX in Shizuku.",
            "Grant"
        )
        Status.NOT_RUNNING -> Triple(
            "Shizuku is not running",
            "Open Shizuku and start it (Wireless debugging or ADB), then come back.",
            "Check again"
        )
        Status.NO_SHIZUKU -> Triple(
            "Shizuku not installed",
            "Install Shizuku from its official page, start it, then come back.",
            "Check again"
        )
    }
    val dot = if (vm.status == Status.READY) p.good else p.warn
    Row(Modifier.fillMaxWidth().glass().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(dot, CircleShape))
        Box(Modifier.size(10.dp))
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(info.first, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(info.second, color = p.soft, fontSize = 12.sp)
        }
        if (info.third != null) {
            GlassButton(info.third!!) {
                if (vm.status == Status.NEED_PERMISSION) vm.requestPermission() else vm.retry()
            }
        }
    }
}
