package com.akula.claudex;

interface IShellService {
    // Transaction id required by Shizuku for the destroy call.
    void destroy() = 16777114;

    // Runs ONE allow-listed command with Shizuku's (shell) privileges. Stops it after timeoutMs.
    String exec(String command, long timeoutMs) = 1;

    // Stops the command that is currently running (used by the Cancel button).
    void cancel() = 2;
}
